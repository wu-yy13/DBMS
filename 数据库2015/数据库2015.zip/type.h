/*
 * type.h
 *
 *  Created on: 2015年10月28日
 *      Author: 吴永宇
 */

#ifndef DBMANAGER_TYPE_H_
#define DBMANAGER_TYPE_H_
/*
*@enum
*@parm TYPE_INT
*@parm TYPE_VARCHAR
*/
enum TYPE {
    TYPE_INT,
    TYPE_VARCHAR
};

#endif /* DBMANAGER_TYPE_H_ */
